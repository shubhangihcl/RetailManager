package com.service.impl;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*; 

import java.util.logging.Logger;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;


import org.mockito.runners.MockitoJUnitRunner;

import com.model.Address;
import com.model.Shop;
 

@RunWith(MockitoJUnitRunner.class) 
public class AddressConverterImplTest {
	private final static Logger LOGGER = Logger.getLogger(AddressConverterImpl.class.getName()); 
	private static Shop shop;
	private static Address address;
    
	@Before  
    public void setUp() {  
    	LOGGER.info("Setup");
    	shop=mock(Shop.class);
        address =mock(Address.class);
    	shop.setName("SAMSUNG");
    	address.setNumber("1234");
    	address.setPostCode("1234");
    	shop.setAddress(address);
    }  
    @After  
    public void tearDown() {  
    	LOGGER.info("tearDown");
    	address=null;
        shop=null;
    }  
  
	@Test
	public void testConvertToLatLong() {
		LOGGER.info("Test Method testConvertToLatLong");
		when (shop.getLatitude()).thenReturn("124578");
		when(shop.getLongitude()).thenReturn("124578");
		assertEquals(shop.getLatitude(), "124578");
		assertEquals(shop.getLongitude(), "124578");
	}
	@Test
	public void testConvertFromLatLong() {
		LOGGER.info("Test Method testConvertFromLatLong");
		String addressNumber = "12345";
		String postCode = "12345";
		when(shop.getAddress()).thenReturn(address);
		when(shop.getAddress().getNumber()).thenReturn(addressNumber);
		when(shop.getAddress().getPostCode()).thenReturn(postCode);
		assertEquals(shop.getAddress().getNumber(), addressNumber);
		assertEquals(shop.getAddress().getPostCode(),postCode);
	}
}
